﻿using System;
using System.Net.Http;
using System.Threading.Tasks;
using Microsoft.Extensions.Caching.Memory;

namespace Projeto_final.Services;

public class ExternalIntegrationService
{
    private readonly HttpClient _httpClient;
    private readonly IMemoryCache _cache;

    public ExternalIntegrationService(HttpClient httpClient, IMemoryCache cache)
    {
        _httpClient = httpClient;
        _cache = cache;
    }

    public async Task<string> GetInventoryStatusAsync(string sku)
    {
        string cacheKey = $"inventory_{sku}";

        if (_cache.TryGetValue(cacheKey, out string? cachedData) && cachedData != null)
        {
            return $"[CACHE] {cachedData}";
        }

        try
        {
            var response = await _httpClient.GetAsync($"/inventory/{sku}");
            if (response.IsSuccessStatusCode)
            {
                var content = await response.Content.ReadAsStringAsync();
                _cache.Set(cacheKey, content, TimeSpan.FromSeconds(30));
                return $"[API EXTERNA] {content}";
            }
        }
        catch
        {
            return "[FALLBACK] Serviço de inventário indisponível.";
        }

        return "[ERRO] Erro ao obter dados do inventário.";
    }
}