﻿using Projeto_final.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Projeto_final.Controllers;

[ApiController]
[Route("api/[controller]")]
public class ProductsController : ControllerBase
{
    private readonly ExternalIntegrationService _integrationService;

    public ProductsController(ExternalIntegrationService integrationService)
    {
        _integrationService = integrationService;
    }

    
    [HttpGet]
    public IActionResult GetAll()
    {
        return Ok(new[]
        {
            new { Id = 1, Name = "Teclado Mecânico", Price = 59.99 },
            new { Id = 2, Name = "Rato Gaming", Price = 29.99 }
        });
    }

    
    [HttpGet("{sku}/stock")]
    [Authorize] 
    public async Task<IActionResult> GetStock(string sku)
    {
        var result = await _integrationService.GetInventoryStatusAsync(sku);
        return Ok(result);
    }
}
